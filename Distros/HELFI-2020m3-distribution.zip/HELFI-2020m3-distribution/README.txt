                    HELFI: 

 a Hebrew-Greek-Finnish Parallel Bible Corpus 
 with Cross-Lingual Morpheme Alignment:

           ISLRN 840-665-876-625-0


Parts
-----

* Finnish1938 
  
  The Finnish 1933/1938 Bible Translation with lemmas, morphology and
  cross-lingual morpheme alignment
  (https://github.com/amikael/HELFI/tree/master/Finnish1938)

* Greek1904

  The Nestle 1904 Greek New Testament with lemmas and morphology in a
  column-oriented file format containing token numbers for
  cross-lingual alignment
  (https://github.com/amikael/HELFI/tree/master/Greek1904)

* Hebrew1008

  The Leningrad Codex Hebrew Bible (the Tanach) with the OSHB lemmas
  and morphology in a column-oriented file format containing token
  numbers for cross-lingual alignment
  (https://github.com/amikael/HELFI/tree/master/Hebrew1008) 

This corpus is under several licenses that cover its copyrighted
parts.  You must give appropriate credit, provide links to the
licenses, and indicate if changes were made.

Important Files
---------------

* CITING.txt 

  How to cite or attribute the cross-lingual morpheme
  alignment (https://github.com/amikael/HELFI/blob/master/CITING.md

* LICENSES.txt

  The license and the parts that remain in the public domain or under
  their current restrictions
  (https://github.com/amikael/HELFI/blob/master/LICENSES.md)

* ACKNOWLEDGEMENTS.txt 

  Acknowledgements and contributors
  (https://github.com/amikael/HELFI/blob/master/CONTRIB.md)

* TODO.txt

  To-do's and bug issues of the corpus
  (https://github.com/amikael/HELFI/blob/master/ISSUES.md)

Contact
-------

The HELFI corpus is maintained by Anssi Yli-Jyrä (_firstname.yli-jyra@helsinki.fi_).

